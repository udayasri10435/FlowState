import { LayoutDashboard, FileText, Calendar, BarChart2, LogOut, User as UserIcon } from "lucide-react";
import { cn } from "../lib/utils";
import { User } from "firebase/auth";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  user: User;
}

export function Sidebar({ activeTab, setActiveTab, onLogout, user }: SidebarProps) {
  const menuItems = [
    { id: "tasks", label: "Tasks", icon: LayoutDashboard },
    { id: "notes", label: "Notes", icon: FileText },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "analytics", label: "Analytics", icon: BarChart2 },
  ];

  return (
    <aside className="w-64 border-r border-[#E6E6E6] bg-white flex flex-col shrink-0">
      <div className="p-6">
        <h1 className="text-2xl font-serif font-light text-[#1A1A1A]">FlowState</h1>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 font-serif",
              activeTab === item.id
                ? "bg-[#5A5A40] text-white shadow-lg shadow-[#5A5A40]/20"
                : "text-[#5A5A40] hover:bg-[#F5F5F0]"
            )}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-[#E6E6E6]">
        <div className="flex items-center gap-3 px-4 py-3 mb-2">
          {user.photoURL ? (
            <img src={user.photoURL} alt={user.displayName || ""} className="w-8 h-8 rounded-full" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-[#5A5A40] flex items-center justify-center text-white">
              <UserIcon className="w-4 h-4" />
            </div>
          )}
          <div className="min-w-0">
            <p className="text-sm font-medium text-[#1A1A1A] truncate">{user.displayName}</p>
            <p className="text-xs text-[#5A5A40] truncate">{user.email}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-red-600 hover:bg-red-50 transition-colors font-serif"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
