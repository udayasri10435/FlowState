import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db, auth } from "../firebase";
import { Sparkles, Loader2, Send, X, PlusCircle, CheckCircle } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import { parseNaturalLanguageTask } from "../services/aiService";

interface AIAssistantProps {
  currentWorkspaceId: string | null;
}

export function AIAssistant({ currentWorkspaceId }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleAISubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !currentWorkspaceId) return;

    setLoading(true);
    try {
      const task = await parseNaturalLanguageTask(input);
      if (task) {
        setResult(task);
      }
    } catch (err) {
      console.error("AI Assistant error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmTask = async () => {
    if (!result || !currentWorkspaceId) return;
    try {
      await addDoc(collection(db, "tasks"), {
        ...result,
        workspaceId: currentWorkspaceId,
        assigneeId: auth.currentUser?.uid,
        createdAt: serverTimestamp(),
      });
      setResult(null);
      setInput("");
      setIsOpen(false);
    } catch (err) {
      console.error("Error confirming task:", err);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300 font-serif text-sm",
          isOpen ? "bg-[#5A5A40] text-white shadow-lg" : "bg-white text-[#5A5A40] border border-[#E6E6E6] hover:bg-[#F5F5F0]"
        )}
      >
        <Sparkles className={cn("w-4 h-4", isOpen && "animate-pulse")} />
        AI Assistant
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-30" onClick={() => setIsOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              className="absolute top-full right-0 mt-4 w-96 bg-white rounded-[32px] shadow-2xl border border-[#E6E6E6] z-40 overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#5A5A40]" />
                    <h3 className="font-serif font-medium text-[#1A1A1A]">AI Assistant</h3>
                  </div>
                  <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-[#F5F5F0] rounded-full">
                    <X className="w-4 h-4 text-[#5A5A40]" />
                  </button>
                </div>

                <form onSubmit={handleAISubmit} className="space-y-4">
                  <div className="relative">
                    <textarea
                      autoFocus
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="e.g., 'Create a high priority task to review the Q3 budget by Friday'"
                      className="w-full h-24 p-4 bg-[#F5F5F0] rounded-2xl text-sm font-serif focus:outline-none focus:ring-2 focus:ring-[#5A5A40] resize-none"
                    />
                    <button
                      type="submit"
                      disabled={loading || !input.trim()}
                      className="absolute bottom-3 right-3 p-2 bg-[#5A5A40] text-white rounded-xl hover:bg-[#4A4A30] transition-colors disabled:opacity-50"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </button>
                  </div>
                </form>

                <AnimatePresence>
                  {result && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6 p-4 bg-[#F5F5F0] rounded-2xl border border-[#E6E6E6]"
                    >
                      <p className="text-xs font-serif text-[#5A5A40] mb-2 uppercase tracking-wider font-bold">Proposed Task</p>
                      <h4 className="font-serif text-[#1A1A1A] mb-3">{result.title}</h4>
                      <div className="flex items-center justify-between">
                        <span className={cn(
                          "text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full",
                          result.priority === "high" ? "bg-red-50 text-red-600" :
                          result.priority === "medium" ? "bg-amber-50 text-amber-600" :
                          "bg-blue-50 text-blue-600"
                        )}>
                          {result.priority}
                        </span>
                        <button
                          onClick={handleConfirmTask}
                          className="flex items-center gap-2 px-3 py-1.5 bg-[#5A5A40] text-white rounded-xl text-xs font-serif hover:bg-[#4A4A30] transition-colors"
                        >
                          <CheckCircle className="w-3 h-3" />
                          Confirm Task
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="mt-6 pt-6 border-t border-[#E6E6E6]">
                  <p className="text-[10px] text-[#5A5A40] font-serif italic text-center">
                    "FlowState AI can help you create tasks, summarize notes, and more."
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
