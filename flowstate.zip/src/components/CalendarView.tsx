import { useState, useEffect } from "react";
import { collection, query, where, onSnapshot, addDoc, serverTimestamp, Timestamp } from "firebase/firestore";
import { db } from "../firebase";
import { ChevronLeft, ChevronRight, Plus, Sparkles, Loader2, Clock, Calendar as CalendarIcon } from "lucide-react";
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from "date-fns";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import { generateMeetingAgenda } from "../services/aiService";

interface CalendarViewProps {
  workspaceId: string;
}

export function CalendarView({ workspaceId }: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiAgenda, setAiAgenda] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, "events"), where("workspaceId", "==", workspaceId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEvents(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [workspaceId]);

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

  const handleAddEvent = async (date: Date) => {
    if (!newEventTitle.trim()) return;
    try {
      await addDoc(collection(db, "events"), {
        title: newEventTitle.trim(),
        start: Timestamp.fromDate(date),
        end: Timestamp.fromDate(new Date(date.getTime() + 3600000)), // 1 hour later
        workspaceId,
        createdAt: serverTimestamp(),
      });
      setNewEventTitle("");
      setIsAdding(false);
    } catch (err) {
      console.error("Error adding event:", err);
    }
  };

  const handleGenerateAgenda = async () => {
    setLoadingAI(true);
    try {
      // Get some context from tasks and notes (simplified for demo)
      const agenda = await generateMeetingAgenda(["Review Q3 Budget", "Finalize API Docs"], ["Discussed auth flow", "Meeting with design team"]);
      setAiAgenda(agenda);
    } catch (err) {
      console.error("AI Agenda error:", err);
    } finally {
      setLoadingAI(false);
    }
  };

  return (
    <div className="h-full flex gap-6 overflow-hidden">
      <div className="flex-1 flex flex-col bg-white rounded-[32px] border border-[#E6E6E6] overflow-hidden">
        <header className="px-6 py-4 border-b border-[#E6E6E6] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-serif font-medium text-[#1A1A1A]">
              {format(currentDate, "MMMM yyyy")}
            </h2>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                className="p-2 hover:bg-[#F5F5F0] rounded-full transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-[#5A5A40]" />
              </button>
              <button
                onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                className="p-2 hover:bg-[#F5F5F0] rounded-full transition-colors"
              >
                <ChevronRight className="w-5 h-5 text-[#5A5A40]" />
              </button>
            </div>
          </div>
          <button
            onClick={handleGenerateAgenda}
            disabled={loadingAI}
            className="flex items-center gap-2 px-4 py-2 bg-[#5A5A40] text-white rounded-full text-sm font-serif hover:bg-[#4A4A30] transition-colors disabled:opacity-50"
          >
            {loadingAI ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            AI Agenda
          </button>
        </header>

        <div className="flex-1 grid grid-cols-7 auto-rows-fr">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="p-4 text-center text-xs font-serif font-bold text-[#5A5A40] border-b border-[#E6E6E6] uppercase tracking-wider">
              {day}
            </div>
          ))}
          {calendarDays.map((day, idx) => {
            const dayEvents = events.filter((e) => isSameDay(e.start.toDate(), day));
            return (
              <div
                key={idx}
                className={cn(
                  "p-2 border-b border-r border-[#E6E6E6] min-h-[120px] transition-colors hover:bg-[#F5F5F0]/30",
                  !isSameMonth(day, monthStart) && "bg-[#F5F5F0]/50 text-[#5A5A40]/30",
                  isSameDay(day, new Date()) && "bg-[#5A5A40]/5"
                )}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={cn(
                    "text-sm font-serif",
                    isSameDay(day, new Date()) && "w-7 h-7 flex items-center justify-center bg-[#5A5A40] text-white rounded-full"
                  )}>
                    {format(day, "d")}
                  </span>
                  <button
                    onClick={() => setIsAdding(true)}
                    className="p-1 opacity-0 hover:bg-white rounded-lg group-hover:opacity-100 transition-opacity"
                  >
                    <Plus className="w-4 h-4 text-[#5A5A40]" />
                  </button>
                </div>
                <div className="space-y-1">
                  {dayEvents.map((event) => (
                    <div
                      key={event.id}
                      className="px-2 py-1 bg-[#5A5A40] text-white text-[10px] font-serif rounded-lg truncate shadow-sm"
                      title={event.title}
                    >
                      {event.title}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {aiAgenda && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="w-80 bg-white rounded-[32px] border border-[#E6E6E6] p-6 overflow-y-auto shrink-0"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-serif font-medium text-[#1A1A1A]">AI Agenda</h3>
              <button
                onClick={() => setAiAgenda(null)}
                className="text-xs text-[#5A5A40] hover:underline font-serif"
              >
                Close
              </button>
            </div>
            <div className="prose prose-stone prose-sm font-serif text-[#1A1A1A]">
              <pre className="whitespace-pre-wrap font-serif text-sm leading-relaxed">
                {aiAgenda}
              </pre>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
