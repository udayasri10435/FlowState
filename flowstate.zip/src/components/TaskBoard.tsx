import { useState, useEffect } from "react";
import { collection, query, where, onSnapshot, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import { Plus, MoreVertical, CheckCircle2, Circle, Clock, Sparkles, Trash2, Loader2, Link as LinkIcon, AlertCircle } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import { breakdownTask } from "../services/aiService";

interface TaskBoardProps {
  workspaceId: string;
  userId: string;
}

export function TaskBoard({ workspaceId, userId }: TaskBoardProps) {
  const [tasks, setTasks] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState<string | null>(null);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [selectedDependencies, setSelectedDependencies] = useState<string[]>([]);
  const [loadingAI, setLoadingAI] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, "tasks"), where("workspaceId", "==", workspaceId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [workspaceId]);

  const columns = [
    { id: "todo", label: "To Do", icon: Circle },
    { id: "in-progress", label: "In Progress", icon: Clock },
    { id: "done", label: "Done", icon: CheckCircle2 },
  ];

  const handleAddTask = async (status: string) => {
    if (!newTaskTitle.trim()) return;
    try {
      await addDoc(collection(db, "tasks"), {
        title: newTaskTitle.trim(),
        status,
        priority: "medium",
        workspaceId,
        assigneeId: userId,
        dependencies: selectedDependencies,
        createdAt: serverTimestamp(),
      });
      setNewTaskTitle("");
      setSelectedDependencies([]);
      setIsAdding(null);
    } catch (err) {
      console.error("Error adding task:", err);
    }
  };

  const handleUpdateStatus = async (taskId: string, status: string) => {
    if (status === "in-progress" || status === "done") {
      const task = tasks.find(t => t.id === taskId);
      if (task?.dependencies?.length > 0) {
        const incompleteDependencies = task.dependencies.filter((depId: string) => {
          const depTask = tasks.find(t => t.id === depId);
          return depTask && depTask.status !== "done";
        });
        if (incompleteDependencies.length > 0) {
          setError(`Dependencies must be completed first.`);
          setTimeout(() => setError(null), 3000);
          return;
        }
      }
    }

    try {
      await updateDoc(doc(db, "tasks", taskId), { status });
    } catch (err) {
      console.error("Error updating task:", err);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await deleteDoc(doc(db, "tasks", taskId));
    } catch (err) {
      console.error("Error deleting task:", err);
    }
  };

  const handleAIByBreakdown = async (task: any) => {
    setLoadingAI(task.id);
    try {
      const subtasks = await breakdownTask(task.title);
      for (const sub of subtasks) {
        await addDoc(collection(db, "tasks"), {
          title: sub,
          status: "todo",
          priority: task.priority,
          workspaceId,
          assigneeId: userId,
          createdAt: serverTimestamp(),
          parentId: task.id,
          dependencies: [task.id], // Subtasks depend on parent by default
        });
      }
    } catch (err) {
      console.error("AI Breakdown error:", err);
    } finally {
      setLoadingAI(null);
    }
  };

  const toggleDependency = (id: string) => {
    setSelectedDependencies(prev => 
      prev.includes(id) ? prev.filter(d => d !== id) : [...prev, id]
    );
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center gap-2 bg-red-50 text-red-600 px-4 py-2 rounded-xl border border-red-100 text-sm font-serif"
          >
            <AlertCircle className="w-4 h-4" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex gap-6 overflow-x-auto pb-4">
        {columns.map((column) => (
          <div key={column.id} className="w-80 shrink-0 flex flex-col bg-[#F5F5F0]/50 rounded-[32px] p-4 border border-[#E6E6E6]">
            <div className="flex items-center justify-between mb-4 px-2">
              <div className="flex items-center gap-2">
                <column.icon className={cn("w-5 h-5", column.id === "done" ? "text-green-600" : "text-[#5A5A40]")} />
                <h3 className="font-serif font-medium text-[#1A1A1A]">{column.label}</h3>
                <span className="text-xs text-[#5A5A40] bg-white px-2 py-0.5 rounded-full border border-[#E6E6E6]">
                  {tasks.filter((t) => t.status === column.id).length}
                </span>
              </div>
              <button
                onClick={() => {
                  setIsAdding(column.id);
                  setSelectedDependencies([]);
                }}
                className="p-1 hover:bg-white rounded-full transition-colors text-[#5A5A40]"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto px-1">
              <AnimatePresence>
                {isAdding === column.id && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white p-4 rounded-2xl shadow-sm border border-[#E6E6E6]"
                  >
                    <input
                      autoFocus
                      type="text"
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      placeholder="What needs to be done?"
                      className="w-full text-sm font-serif mb-3 focus:outline-none"
                      onKeyDown={(e) => e.key === "Enter" && handleAddTask(column.id)}
                    />
                    
                    <div className="mb-3">
                      <p className="text-[10px] font-bold text-[#5A5A40] uppercase tracking-wider mb-2">Depends on:</p>
                      <div className="max-h-32 overflow-y-auto space-y-1">
                        {tasks.filter(t => t.status !== 'done').map(t => (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => toggleDependency(t.id)}
                            className={cn(
                              "w-full text-left px-2 py-1 rounded-lg text-[10px] font-serif transition-colors",
                              selectedDependencies.includes(t.id) ? "bg-[#5A5A40] text-white" : "hover:bg-[#F5F5F0] text-[#5A5A40]"
                            )}
                          >
                            {t.title}
                          </button>
                        ))}
                        {tasks.filter(t => t.status !== 'done').length === 0 && (
                          <p className="text-[10px] text-[#5A5A40] italic">No active tasks to depend on.</p>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setIsAdding(null)}
                        className="px-3 py-1 text-xs font-serif text-[#5A5A40] hover:bg-[#F5F5F0] rounded-lg"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleAddTask(column.id)}
                        className="px-3 py-1 text-xs font-serif bg-[#5A5A40] text-white rounded-lg"
                      >
                        Add Task
                      </button>
                    </div>
                  </motion.div>
                )}

                {tasks
                  .filter((t) => t.status === column.id)
                  .map((task) => (
                    <motion.div
                      key={task.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="group bg-white p-4 rounded-2xl shadow-sm border border-[#E6E6E6] hover:shadow-md transition-all duration-200"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed">{task.title}</p>
                          {task.dependencies?.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {task.dependencies.map((depId: string) => {
                                const depTask = tasks.find(t => t.id === depId);
                                return (
                                  <div key={depId} className={cn(
                                    "flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9px] font-serif border",
                                    depTask?.status === 'done' ? "bg-green-50 text-green-700 border-green-100" : "bg-amber-50 text-amber-700 border-amber-100"
                                  )}>
                                    <LinkIcon className="w-2 h-2" />
                                    {depTask?.title || "Unknown Task"}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          <button
                            onClick={() => handleAIByBreakdown(task)}
                            disabled={loadingAI === task.id}
                            className="p-1 hover:bg-[#F5F5F0] rounded-lg text-[#5A5A40] disabled:opacity-50"
                            title="AI Breakdown"
                          >
                            {loadingAI === task.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => handleDeleteTask(task.id)}
                            className="p-1 hover:bg-red-50 rounded-lg text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full",
                            task.priority === "high" ? "bg-red-50 text-red-600" :
                            task.priority === "medium" ? "bg-amber-50 text-amber-600" :
                            "bg-blue-50 text-blue-600"
                          )}>
                            {task.priority}
                          </span>
                        </div>
                        <select
                          value={task.status}
                          onChange={(e) => handleUpdateStatus(task.id, e.target.value)}
                          className="text-[10px] font-serif bg-[#F5F5F0] border-none rounded-lg px-2 py-1 focus:ring-0 cursor-pointer"
                        >
                          {columns.map((c) => (
                            <option key={c.id} value={c.id}>{c.label}</option>
                          ))}
                        </select>
                      </div>
                    </motion.div>
                  ))}
              </AnimatePresence>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
