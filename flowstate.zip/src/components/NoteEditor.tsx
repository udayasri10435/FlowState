import { useState, useEffect } from "react";
import { collection, query, where, onSnapshot, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import { Plus, Search, Trash2, Sparkles, Loader2, Save, FileText, ChevronLeft } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import { summarizeNote } from "../services/aiService";

interface NoteEditorProps {
  workspaceId: string;
  userId: string;
}

export function NoteEditor({ workspaceId, userId }: NoteEditorProps) {
  const [notes, setNotes] = useState<any[]>([]);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [loadingAI, setLoadingAI] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const q = query(collection(db, "notes"), where("workspaceId", "==", workspaceId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotes(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, [workspaceId]);

  const activeNote = notes.find((n) => n.id === activeNoteId);

  const handleCreateNote = async () => {
    try {
      const docRef = await addDoc(collection(db, "notes"), {
        title: "Untitled Note",
        content: "",
        workspaceId,
        authorId: userId,
        lastEditedBy: userId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setActiveNoteId(docRef.id);
      setIsEditing(true);
    } catch (err) {
      console.error("Error creating note:", err);
    }
  };

  const handleUpdateNote = async (updates: any) => {
    if (!activeNoteId) return;
    try {
      await updateDoc(doc(db, "notes", activeNoteId), {
        ...updates,
        lastEditedBy: userId,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      console.error("Error updating note:", err);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      await deleteDoc(doc(db, "notes", id));
      if (activeNoteId === id) {
        setActiveNoteId(null);
        setIsEditing(false);
      }
    } catch (err) {
      console.error("Error deleting note:", err);
    }
  };

  const handleAISummarize = async () => {
    if (!activeNote?.content) return;
    setLoadingAI(true);
    try {
      const summary = await summarizeNote(activeNote.content);
      const newContent = `${activeNote.content}\n\n---\n### AI Summary\n${summary}`;
      await handleUpdateNote({ content: newContent });
    } catch (err) {
      console.error("AI Summarize error:", err);
    } finally {
      setLoadingAI(false);
    }
  };

  const filteredNotes = notes.filter((n) =>
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex gap-6 overflow-hidden">
      {/* Sidebar */}
      <div className={cn(
        "w-80 shrink-0 flex flex-col bg-white rounded-[32px] border border-[#E6E6E6] overflow-hidden transition-all duration-300",
        activeNoteId && "hidden md:flex"
      )}>
        <div className="p-4 border-b border-[#E6E6E6]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif font-medium text-[#1A1A1A]">Notes</h3>
            <button
              onClick={handleCreateNote}
              className="p-2 bg-[#5A5A40] text-white rounded-full hover:bg-[#4A4A30] transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5A5A40]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full pl-10 pr-4 py-2 bg-[#F5F5F0] rounded-xl text-sm font-serif focus:outline-none focus:ring-2 focus:ring-[#5A5A40]"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredNotes.map((note) => (
            <button
              key={note.id}
              onClick={() => setActiveNoteId(note.id)}
              className={cn(
                "w-full text-left p-4 rounded-2xl transition-all duration-200 group",
                activeNoteId === note.id ? "bg-[#F5F5F0] shadow-sm" : "hover:bg-[#F5F5F0]/50"
              )}
            >
              <div className="flex justify-between items-start mb-1">
                <h4 className="text-sm font-serif font-medium text-[#1A1A1A] truncate pr-4">{note.title}</h4>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteNote(note.id);
                  }}
                  className="p-1 text-red-600 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-[#5A5A40] font-serif line-clamp-2 italic">
                {note.content || "No content yet..."}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex flex-col bg-white rounded-[32px] border border-[#E6E6E6] overflow-hidden">
        <AnimatePresence mode="wait">
          {activeNoteId ? (
            <motion.div
              key={activeNoteId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full flex flex-col"
            >
              <header className="px-6 py-4 border-b border-[#E6E6E6] flex items-center justify-between shrink-0">
                <div className="flex items-center gap-4 flex-1">
                  <button
                    onClick={() => setActiveNoteId(null)}
                    className="md:hidden p-2 hover:bg-[#F5F5F0] rounded-full"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <input
                    type="text"
                    value={activeNote?.title}
                    onChange={(e) => handleUpdateNote({ title: e.target.value })}
                    className="flex-1 text-xl font-serif font-medium text-[#1A1A1A] focus:outline-none bg-transparent"
                    placeholder="Note Title"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAISummarize}
                    disabled={loadingAI || !activeNote?.content}
                    className="flex items-center gap-2 px-4 py-2 bg-[#5A5A40] text-white rounded-full text-sm font-serif hover:bg-[#4A4A30] transition-colors disabled:opacity-50"
                  >
                    {loadingAI ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Summarize
                  </button>
                  <button
                    onClick={() => setIsEditing(!isEditing)}
                    className="px-4 py-2 bg-[#F5F5F0] text-[#5A5A40] rounded-full text-sm font-serif hover:bg-[#E6E6E6] transition-colors"
                  >
                    {isEditing ? "Preview" : "Edit"}
                  </button>
                </div>
              </header>

              <div className="flex-1 overflow-y-auto p-8">
                {isEditing ? (
                  <textarea
                    value={activeNote?.content}
                    onChange={(e) => handleUpdateNote({ content: e.target.value })}
                    className="w-full h-full resize-none font-serif text-[#1A1A1A] leading-relaxed focus:outline-none bg-transparent"
                    placeholder="Start writing in markdown..."
                  />
                ) : (
                  <div className="prose prose-stone max-w-none font-serif text-[#1A1A1A]">
                    {activeNote?.content ? (
                      <ReactMarkdown>{activeNote.content}</ReactMarkdown>
                    ) : (
                      <p className="text-[#5A5A40] italic">No content yet. Click edit to start writing.</p>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
              <div className="w-16 h-16 bg-[#F5F5F0] rounded-full flex items-center justify-center mb-4">
                <FileText className="w-8 h-8 text-[#5A5A40]" />
              </div>
              <h2 className="text-2xl font-serif text-[#1A1A1A] mb-2">Select a Note</h2>
              <p className="text-[#5A5A40] font-serif italic max-w-xs">
                Choose a note from the sidebar or create a new one to get started.
              </p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
