import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import { Plus, ChevronDown, Check } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";

interface WorkspaceSelectorProps {
  workspaces: any[];
  currentWorkspaceId: string | null;
  setCurrentWorkspaceId: (id: string) => void;
  userId: string;
}

export function WorkspaceSelector({ workspaces, currentWorkspaceId, setCurrentWorkspaceId, userId }: WorkspaceSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newWorkspaceName, setNewWorkspaceName] = useState("");

  const currentWorkspace = workspaces.find((w) => w.id === currentWorkspaceId);

  const handleCreateWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkspaceName.trim()) return;

    try {
      const docRef = await addDoc(collection(db, "workspaces"), {
        name: newWorkspaceName.trim(),
        ownerId: userId,
        members: [userId],
        createdAt: serverTimestamp(),
      });
      setCurrentWorkspaceId(docRef.id);
      setNewWorkspaceName("");
      setIsCreating(false);
      setIsOpen(false);
    } catch (err) {
      console.error("Error creating workspace:", err);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 rounded-full hover:bg-[#F5F5F0] transition-colors font-serif text-[#1A1A1A]"
      >
        <span className="font-medium">{currentWorkspace?.name || "Select Workspace"}</span>
        <ChevronDown className={cn("w-4 h-4 transition-transform", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute top-full left-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-[#E6E6E6] z-20 overflow-hidden"
            >
              <div className="p-2">
                {workspaces.map((ws) => (
                  <button
                    key={ws.id}
                    onClick={() => {
                      setCurrentWorkspaceId(ws.id);
                      setIsOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center justify-between px-4 py-2 rounded-xl text-left font-serif transition-colors",
                      currentWorkspaceId === ws.id ? "bg-[#F5F5F0] text-[#1A1A1A]" : "text-[#5A5A40] hover:bg-[#F5F5F0]"
                    )}
                  >
                    <span>{ws.name}</span>
                    {currentWorkspaceId === ws.id && <Check className="w-4 h-4" />}
                  </button>
                ))}

                <div className="h-px bg-[#E6E6E6] my-2" />

                {isCreating ? (
                  <form onSubmit={handleCreateWorkspace} className="p-2">
                    <input
                      autoFocus
                      type="text"
                      value={newWorkspaceName}
                      onChange={(e) => setNewWorkspaceName(e.target.value)}
                      placeholder="Workspace name..."
                      className="w-full px-3 py-2 rounded-lg border border-[#E6E6E6] text-sm mb-2 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]"
                    />
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        className="flex-1 bg-[#5A5A40] text-white py-1.5 rounded-lg text-xs font-medium"
                      >
                        Create
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsCreating(false)}
                        className="flex-1 bg-[#F5F5F0] text-[#5A5A40] py-1.5 rounded-lg text-xs font-medium"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <button
                    onClick={() => setIsCreating(true)}
                    className="w-full flex items-center gap-2 px-4 py-2 rounded-xl text-[#5A5A40] hover:bg-[#F5F5F0] transition-colors font-serif"
                  >
                    <Plus className="w-4 h-4" />
                    New Workspace
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
