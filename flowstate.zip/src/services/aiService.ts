import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export const summarizeNote = async (content: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Summarize the following note into a concise set of bullet points:\n\n${content}`,
    config: {
      systemInstruction: "You are a helpful productivity assistant. Your summaries are clear, concise, and professional.",
    },
  });
  return response.text;
};

export const breakdownTask = async (taskTitle: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Break down the task "${taskTitle}" into 3-5 actionable subtasks. Return the result as a JSON array of strings.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
    },
  });
  try {
    return JSON.parse(response.text);
  } catch (e) {
    return [];
  }
};

export const generateMeetingAgenda = async (tasks: string[], notes: string[]) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate a meeting agenda based on the following context:\n\nTasks:\n${tasks.join("\n")}\n\nRecent Notes:\n${notes.join("\n")}`,
    config: {
      systemInstruction: "You are a professional meeting facilitator. Create a structured agenda with time allocations.",
    },
  });
  return response.text;
};

export const parseNaturalLanguageTask = async (input: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Extract task details from the following input: "${input}". Return a JSON object with 'title', 'priority' (low, medium, high), and 'status' (todo).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          priority: { type: Type.STRING, enum: ["low", "medium", "high"] },
          status: { type: Type.STRING, enum: ["todo"] },
        },
        required: ["title", "priority", "status"],
      },
    },
  });
  try {
    return JSON.parse(response.text);
  } catch (e) {
    return null;
  }
};
