import { useEffect, useState } from "react";
import { onAuthStateChanged, User } from "firebase/auth";
import { collection, query, where, onSnapshot, doc, setDoc, getDoc, getDocFromServer } from "firebase/firestore";
import { auth, db, signIn, logOut } from "./firebase";
import { Sidebar } from "./components/Sidebar";
import { TaskBoard } from "./components/TaskBoard";
import { NoteEditor } from "./components/NoteEditor";
import { CalendarView } from "./components/CalendarView";
import { AIAssistant } from "./components/AIAssistant";
import { WorkspaceSelector } from "./components/WorkspaceSelector";
import { LogIn, Loader2, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("tasks");
  const [currentWorkspaceId, setCurrentWorkspaceId] = useState<string | null>(null);
  const [workspaces, setWorkspaces] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUser(user);
        // Sync user profile to Firestore
        const userDoc = doc(db, "users", user.uid);
        const userSnap = await getDoc(userDoc);
        if (!userSnap.exists()) {
          await setDoc(userDoc, {
            displayName: user.displayName || "Anonymous",
            email: user.email || "",
            photoURL: user.photoURL || "",
            role: "member",
          });
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;

    // Test connection to Firestore
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, "users", user.uid));
      } catch (err: any) {
        if (err.message?.includes("the client is offline")) {
          setError("Firebase connection error. Please check your configuration.");
        }
      }
    };
    testConnection();

    // Listen to workspaces where user is owner or member
    const q = query(
      collection(db, "workspaces"),
      where("members", "array-contains", user.uid)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ws = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setWorkspaces(ws);
      if (ws.length > 0 && !currentWorkspaceId) {
        setCurrentWorkspaceId(ws[0].id);
      }
    }, (err) => {
      console.error("Workspaces snapshot error:", err);
    });

    // Also listen to workspaces where user is owner
    const qOwner = query(
      collection(db, "workspaces"),
      where("ownerId", "==", user.uid)
    );
    const unsubscribeOwner = onSnapshot(qOwner, (snapshot) => {
      const ws = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setWorkspaces((prev) => {
        const combined = [...prev];
        ws.forEach((w) => {
          if (!combined.find((c) => c.id === w.id)) {
            combined.push(w);
          }
        });
        return combined;
      });
      if (ws.length > 0 && !currentWorkspaceId) {
        setCurrentWorkspaceId(ws[0].id);
      }
    });

    return () => {
      unsubscribe();
      unsubscribeOwner();
    };
  }, [user]);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-[#F5F5F0]">
        <Loader2 className="w-8 h-8 animate-spin text-[#5A5A40]" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-[#F5F5F0] p-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white p-8 rounded-[32px] shadow-xl border border-[#E6E6E6]"
        >
          <h1 className="text-4xl font-serif font-light text-[#1A1A1A] mb-4">FlowState</h1>
          <p className="text-[#5A5A40] mb-8 font-serif italic">
            A modular, real-time collaborative productivity suite.
          </p>
          <button
            onClick={signIn}
            className="w-full flex items-center justify-center gap-2 bg-[#5A5A40] text-white py-3 px-6 rounded-full hover:bg-[#4A4A30] transition-colors font-serif"
          >
            <LogIn className="w-5 h-5" />
            Sign in with Google
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex bg-[#F5F5F0] overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={logOut} user={user} />
      
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-[#E6E6E6] bg-white/50 backdrop-blur-md flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-4">
            <WorkspaceSelector
              workspaces={workspaces}
              currentWorkspaceId={currentWorkspaceId}
              setCurrentWorkspaceId={setCurrentWorkspaceId}
              userId={user.uid}
            />
          </div>
          <div className="flex items-center gap-4">
            <AIAssistant currentWorkspaceId={currentWorkspaceId} />
            {error && (
              <div className="flex items-center gap-2 text-red-600 bg-red-50 px-3 py-1 rounded-full text-xs border border-red-100">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab + currentWorkspaceId}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {!currentWorkspaceId ? (
                <div className="h-full flex flex-col items-center justify-center text-center">
                  <h2 className="text-2xl font-serif text-[#1A1A1A] mb-2">No Workspace Selected</h2>
                  <p className="text-[#5A5A40] font-serif italic">Create or join a workspace to get started.</p>
                </div>
              ) : (
                <>
                  {activeTab === "tasks" && <TaskBoard workspaceId={currentWorkspaceId} userId={user.uid} />}
                  {activeTab === "notes" && <NoteEditor workspaceId={currentWorkspaceId} userId={user.uid} />}
                  {activeTab === "calendar" && <CalendarView workspaceId={currentWorkspaceId} />}
                  {activeTab === "analytics" && (
                    <div className="h-full flex flex-col items-center justify-center text-center">
                      <h2 className="text-2xl font-serif text-[#1A1A1A] mb-2">Analytics</h2>
                      <p className="text-[#5A5A40] font-serif italic">Coming soon: Productivity insights powered by AI.</p>
                    </div>
                  )}
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

